from django.apps import AppConfig


class WordloadConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wordload'
