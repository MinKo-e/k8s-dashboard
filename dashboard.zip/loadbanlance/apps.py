from django.apps import AppConfig


class LoadbanlanceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'loadbanlance'
