
from django.urls import path, re_path
from dashboard import views


urlpatterns = [
    # re_path('^namespace_api/$',views.namecpace_api,name='namespace'),
    # re_path('^namespace/$',views.namespace)
]
